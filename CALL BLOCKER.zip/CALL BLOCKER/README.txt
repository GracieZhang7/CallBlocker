I complete all High-level Requirements.
1. I complete ��Block All Calls��button,��Block Unsaved Contacts��button, ��Block From List��button and ��Cancel All Block��button.
2. I complete ��black list��with utilize database.
3. I complete ��black list�� button.
4. I can enter numbers into ��black list��.
5. I have a menu to view ��black list��, and add number button can add a number in ��black list��.

I complete all Functional Requirements.
Figure 1
1. I have a menu show for button and a picture with CS523 logo.
2. I have an image in menu's top.
3. My app have radio buttons to select the mode of operation. 
4. My app have a button to view "black list".
5. My app have a button to add telephone number to "black list".
Figure 2
Run the programming, in the menu there is a photo in the app top and four button they are: ��Block All Calls��button,��Block Unsaved Contacts��button, ��Block From List��button and ��Cancel All Block��button. There is a "black list" button and "add number" button under the four radio buttons.
Figure 3
There is a "add  number" button in the menu, click it and type in the phone number and click "add" button. If the number can save in "black list", it will says "success save new block number" or says:"the number has exist".
Figure 4
Click "Black list" button in the menu, system will switch to a new page. In there is a list of number. Click "edit" or "delete" button to edit or delete the phone number.

I complete all challenge without realm database.
1. I write code in the app to delete numbers from the ��black list��.
2. I write code in the app that allows users to edit numbers in the ��black list��.
3. I use SQL database.

About Impress point.
Call blocker app can hang up the phone when you call in.